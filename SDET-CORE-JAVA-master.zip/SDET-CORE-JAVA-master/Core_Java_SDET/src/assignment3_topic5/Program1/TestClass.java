package assignment3_topic5.Program1;

public class TestClass {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Foundation f = new Foundation();
	//	System.out.println("Accessing private variable" + f.var1);
		System.out.println("Accessing default variable" + f.Var2);
		System.out.println("Accessing protected variable" + f.Var3);
		System.out.println("Accessing public variable" + f.Var4);
		
		//var1 is not accessible
	}

}
