package assignment3_topic5.Program1;

public class Foundation {
	static private int var1;
	static int Var2;
	protected static int Var3;
	public static int Var4;

}
