/*Create a package called Automobile. Define an abstract class called Vehicle.
Vehicle class has the following abstract methods:
public String modelName()
public String registrationNumber()
public String ownerName()
Create TwoWheeler subpackage under Automobile package
Hero class extends Automobile.vehicle class
public int speed() � Returns the current speed of the vehicle.
public void radio() � provides facility to control the radio device
Honda class extends Automobile.vehicle class
public int speed()� Returns the current speed of the vehicle.
public int cdplayer() � provides facility to control the cd player device which is available in the
car and test all the methods by invoking them.*/

package assignment3_topic5.Program3;

public class TestVehicle {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hero hr = new Hero("Hero - Destini", "KL 31 G 4546", "Chinju", 180);
		hr.displayDetailsHero();
		hr.radio();
		System.out.println("**********\n");
		Honda ho = new Honda("Honda Amaze - i-VTEC", "KL 31 G 4548", "Chinju", 195, 4);
		ho.displayDetails();

	}

}
