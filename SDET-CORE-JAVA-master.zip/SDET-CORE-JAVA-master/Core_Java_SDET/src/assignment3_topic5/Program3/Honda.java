package assignment3_topic5.Program3;

public class Honda extends Vehicle {
	String modelName;
	String registrationNumber;
	String ownerName;
	int speed, cdplayer;

	public Honda(String modelName, String registrationNumber, String ownerName, int speed, int cdplayer) {
		this.modelName = modelName;
		this.registrationNumber = registrationNumber;
		this.ownerName = ownerName;
		this.speed = speed;
		this.cdplayer = cdplayer;
	}

	public String modelName() {
		return modelName;
	}

	public String registrationNumber() {
		return registrationNumber;
	}

	public String ownerName() {
		return ownerName;
	}

	public int getSpeed() {
		return speed;
	}

	public int getcdplayer() {
		return cdplayer;
	}

	public void displayDetails() {
		System.out.println("Model Name: " + modelName + "\n" + "Registration Number: " + registrationNumber + "\n"
				+ "Owner Name: " + ownerName + "\n" + "Speed: " + speed + "\n" + "CdPlayer: " + cdplayer);

	}

}
