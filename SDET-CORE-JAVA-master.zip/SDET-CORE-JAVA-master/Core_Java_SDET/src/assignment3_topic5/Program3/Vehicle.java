package assignment3_topic5.Program3;

public abstract class Vehicle {
	public abstract String modelName();
    public abstract String registrationNumber();
    public abstract String ownerName();

}
