package assignment3_topic5.Program3;

public class Hero {
	String modelName;
	String registrationNumber;
	String ownerName;
	int speed;

	public Hero(String modelName, String registrationNumber, String ownerName, int speed) {
		this.modelName = modelName;
		this.registrationNumber = registrationNumber;
		this.ownerName = ownerName;
		this.speed = speed;
	}

	public String modelName() {
		return modelName;
	}

	public String registrationNumber() {
		return registrationNumber;
	}

	public String ownerName() {
		return ownerName;
	}

	public int getSpeed() {
		return speed;
	}

	public void radio() {
		System.out.println("Facilitates control to radio devices");
	}

	public void displayDetailsHero() {
		System.out.println("Model Name: " + modelName + "\n" + "Registration Number: " + registrationNumber + "\n"
				+ "Owner Name: " + ownerName + "\n" + "Speed: " + speed);

	}

}
