/*Write a Program to accept two Strings Wipro Bangalore as command line arguments and print
the output �Wipro Technologies Bangalore� If the command line is �ABC Mumbai�, then it
should print �ABC Technologies Mumbai� .*/

package assignment3_topic5;

import java.util.Scanner;

public class Program2 {
	public static void main(String args[])

	{
		Scanner in = new Scanner(System.in);
		System.out.println("Enter Company name");
		String s1 = in.next();
		System.out.println("Enter location");
		String s2 = in.next();
		System.out.println(s1 + " Technologies " + s2);
	}

}
