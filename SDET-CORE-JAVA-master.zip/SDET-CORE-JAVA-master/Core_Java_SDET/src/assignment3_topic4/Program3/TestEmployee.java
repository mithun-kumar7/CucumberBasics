/*Create an Employee class with the related attributes and behaviours. Create one more class
EmployeeDB which has the following methods.
a. boolean addEmployee(Employee e)
b. boolean deleteEmployee(int eCode)
c. String showPaySlip(int eCode)
d. Employee[] listAll()
Use an ArrayList which will be used to store the emplyees and use enumeration/iterator to
process the employees.*/

package assignment3_topic4.Program3;

public class TestEmployee {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        EmployeeDB empDb = new EmployeeDB();		
		Employee emp1 = new Employee(101, "Bob", "bob@w3epic.com", 'M', 25000);
		Employee emp2 = new Employee(102, "Alice", "alice@w3epic.com", 'F', 30000);
		Employee emp3 = new Employee(103, "John", "john@w3epic.com", 'M', 20000);
		Employee emp4 = new Employee(104, "Ram", "ram@w3epic.com", 'M', 50000);		
		empDb.addEmployee(emp1);
		empDb.addEmployee(emp2);
		empDb.addEmployee(emp3);
		empDb.addEmployee(emp4);
		for (Employee emp : empDb.listAll())
		System.out.println(emp.GetEmployeeDetails());	
		System.out.println();
		empDb.deleteEmployee(102);		
		for (Employee emp : empDb.listAll())
		System.out.println(emp.GetEmployeeDetails());	
		System.out.println();
		System.out.println(empDb.showPaySlip(104));
	}

}
