/*Write a Java Program, where one thread prints a number ( Generate a random number
using Math.random) and another thread prints the factorial of that given number. Both
the outputs should alternate each other.
Eg: Number : 2
Factorial of 2 : 2
Number : 5
Factorial of 5 : 120
Sensitivity: Internal & Restricted
The program can quit after executing 5 times.*/


package assignment3_topic4;

import java.util.Random;

public class Program1 {
	static Random r = new Random();
    static int num;
	public static void main(String[] args) {
		// TODO Auto-generated method stub	
	      Runnable target=()->{                
	        System.out.println("Random number :");   
	        num=r.nextInt(10);
	            try{                     
	                Thread.sleep(1000);                     
	                System.out.println(num);                 
	                }catch(Exception e)                 
	            {                     
	                    e.printStackTrace();                 
	                    }                    
	      };
	        Thread t1=new Thread(target);         
	        t1.start();         
	        try{             
	            t1.join();         
	            }catch(Exception e)         
	        {             
	                e.printStackTrace();         
	                }                 
	        System.out.println("Factorial of "+num+" is : "); 
	        int f=1;
	        if(num==0) {
	            f=1;
	            System.out.println(f);
	        }else {
	        for(int i=1;i<=num;i++)         
	        {           
	            try{                 
	                Thread.sleep(200);     
	                f=f*i;           
	                }catch(Exception e)             
	            {                 
	                    e.printStackTrace();             
	                    }         
	            }  
	        System.out.println(f); 
	        }
	}

}
