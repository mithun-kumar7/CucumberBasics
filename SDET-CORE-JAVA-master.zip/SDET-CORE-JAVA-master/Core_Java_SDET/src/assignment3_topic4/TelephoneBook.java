/*Write a program creates a HashMap to store name and phone number (Telephone book). When
name is give, we can get back the corresponding phone number.*/

package assignment3_topic4;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class TelephoneBook {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<String, String> telephonebook = new HashMap<>();
		telephonebook.put("Chinju", "9847552652");
		telephonebook.put("Anna", "9847342842");
		telephonebook.put("Bob", "9978425965");
		telephonebook.put("Smith", "7745896548");
		telephonebook.put("Alice", "8847524369");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the name");
		String str = sc.nextLine();
		boolean isKeyPresent = false;
		Iterator<Map.Entry<String, String>> iterator = telephonebook.entrySet().iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, String> entry = iterator.next();
			if (str == entry.getKey()) {
				isKeyPresent = true;
			}
		}
		System.out.println("The Value is: " + telephonebook.get(str));
	}

}
