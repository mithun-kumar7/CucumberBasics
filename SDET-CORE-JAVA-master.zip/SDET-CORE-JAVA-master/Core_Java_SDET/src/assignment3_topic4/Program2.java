/*Write a Java Program which will print the current time on the console every 2 seconds.
 * After doing this activity for 20 seconds the program quits. * 
 */

package assignment3_topic4;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Program2 {
	public static void main(String[] args) throws Throwable {
		// TODO Auto-generated method stub
		int n = 0;
		while (n != 10) {
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			Date d = new Date();
			System.out.println(sdf.format(d));
			n++;
			Thread.sleep(2000);
		}
	}

}
