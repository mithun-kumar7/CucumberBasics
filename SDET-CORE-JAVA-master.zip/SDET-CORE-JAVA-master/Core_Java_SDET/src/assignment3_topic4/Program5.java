/*Write a program to store a group of employee names into a HashSet, retrieve the elements one by
one using an Iterator.*/

package assignment3_topic4;

import java.util.HashSet;
import java.util.Iterator;

public class Program5 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet<String> set = new HashSet<>();
		set.add("Bob");
		set.add("Alice");
		set.add("John");
		set.add("Richard");
		Iterator<String> it = set.iterator();
		while (it.hasNext())
			System.out.println(it.next());
	}

}
