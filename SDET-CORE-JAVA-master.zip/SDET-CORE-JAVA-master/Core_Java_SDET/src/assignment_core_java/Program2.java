/*Write a Java program to print the result of the following operations. 
	Test Data: 
	a. -5 + 8 * 6 
	b. (55+9) % 9  
	c. 20 + -3*5 / 8  
	d. 5 + 15 / 3 * 2 - 8 % 3  
	Expected Output: 
	43  
	1  
	19  
	13 */
package assignment_core_java;

public class Program2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int answer1=-5+8*6;
		System.out.println(answer1);
		int answer2=(55+9) % 9;
		System.out.println(answer2);
		int answer3=20 + -3*5 / 8;
		System.out.println(answer3);
		int answer4=5 + 15 / 3 * 2 - 8 % 3;
		System.out.println(answer4);
	}
}
