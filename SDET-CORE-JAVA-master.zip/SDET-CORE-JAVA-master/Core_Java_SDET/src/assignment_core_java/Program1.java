/*Write a Java program to print 'Hello' on screen and then print your name on a separate line. 
	Expected Output: 
	Hello  
	Mithun Kumar */

package assignment_core_java;

public class Program1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello");
		System.out.println("Mithun Kumar");
	}
}
