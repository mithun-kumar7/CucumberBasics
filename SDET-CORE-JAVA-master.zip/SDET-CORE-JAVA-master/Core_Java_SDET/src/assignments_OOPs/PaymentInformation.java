/*
 * Define a class named Payment that contains a member variable of type double that stores the amount of the payment and appropriate accessor and mutator methods. 
 * Also create a method named paymentDetails that outputs an English sentence to describe the amount of the payment.
 * Next, define a class named CashPayment that is derived from Payment. 
 * This class should redefine the paymentDetails method to indicate that the payment is in cash. 
 * Include appropriate constructor(s).
 * Define a class named CreditCardPayment that is derived from Payment. 
 * This class should contain member variables for the name on the card, expiration date, and credit card number. 
 * Include appropriate constructor(s). 
 * Finally, redefine the paymentDetails method to include all credit card information in the printout.
 * Create a main method that creates at least two CashPayment and two
 * CreditCardPayment objects with different values and calls paymentDetails for each.
 */
package assignments_OOPs;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

class Payment{
	private double amount;

	public double getAmt() {
		return amount;
	}

	public void setAmt(double amount) {
		this.amount = amount;
	}
	
	public void paymentDetails() {
		System.out.println("Amount paid:"+amount);
	}
	
}

class CashPayment extends Payment{
	
	CashPayment(double amt){
		setAmt(amt);
	}
	
	@Override
	public void paymentDetails() {
		System.out.println("Amount paid in Cash:"+getAmt());
	}
}

class CreditCardPayment extends Payment{
	String nameOnCard;
	Date expDate;
	String cardNumber;
	
	CreditCardPayment(String nameOnCard, Date expDate, String cardNumber, double amt){
		this.nameOnCard=nameOnCard;
		this.expDate=expDate;
		this.cardNumber=cardNumber;
		setAmt(amt);
	}
	
	@Override
	public void paymentDetails() {
		SimpleDateFormat sdf = new SimpleDateFormat("mm/yyyy");
		System.out.println("\nAmount paid by Credit Card:"+getAmt()+"\n Credit Card Number :"+cardNumber+" \n Expiration Date : "+sdf.format(expDate)+" \n Name on Card : "+nameOnCard);
	}
}

public class PaymentInformation {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		CashPayment cp1 = new CashPayment(2500.00);
		CashPayment cp2 = new CashPayment(3500.00);
		
		cp1.paymentDetails();
		cp2.paymentDetails();
		SimpleDateFormat sdf = new SimpleDateFormat("mm/yyyy");
		Date expDate=sdf.parse("03/2021");
		CreditCardPayment cc1 = new CreditCardPayment("Mithun kumar", expDate, "4410 4566 9876 0011", 25000);
		cc1.paymentDetails();
		
		Date expDate1=sdf.parse("07/2022");
		CreditCardPayment cc2 = new CreditCardPayment("Munna Kumar", expDate1, "3456 1234 7689 3245", 12500);
		cc2.paymentDetails();

	}

}
