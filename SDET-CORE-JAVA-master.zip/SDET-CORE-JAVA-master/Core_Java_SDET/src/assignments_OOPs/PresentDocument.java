/*Define a class named Document that contains a member variable of type String named text that
 * stores any textual content for the document. Create a method named toString that returns the text
 * field and also include a method to set this value.
 * Next, define a class for Email that is derived from Document and includes member variables for
 * the sender, recipient, and title of an email message. Implement appropriate accessor and mutator
 * methods.
 * The body of the email message should be stored in the inherited variable text. 
 * Redefine the toString method to concatenate all text fields.
 */
package assignments_OOPs;
class Document{
	String text;
	public String toString() {
		return text;
	}
	public void setString(String text) {
		this.text=text;
	}
}

class Email extends Document{
	private String recipient;
	private String sender;
	private String title;
	
	public String getSender() {
		return sender;
	}
	public void setSender(String sender) {
		this.sender=sender;
	}
	public String getRecipient() {
		return recipient;
	}
	public void setRecipient(String recipient) {
		this.recipient=recipient;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title=title;
	}
	public String toString() {
		String text="Title: "+getTitle()+"\nRecipient: "+ getRecipient()+"\nSender: "+getSender()+"\nEmail Body: "+ super.toString();
		return text;
	}
}

public class PresentDocument {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Email email=new Email();
		email.setTitle("OOPs Assignment");
		email.setRecipient("PrasantRastogi");
		email.setSender("Mithun Kumar");
		email.setString("\n Hi, \n OOPs Assignment is done. \n Thanks, \n MithunKumar");
		System.out.println(email.toString());

	}

}
