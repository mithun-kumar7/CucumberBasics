/*Write a program to create a class Book with the following
- attributes: -isbn, title, author, price
- methods :
i. Initialize the data members through parameterized constructor
ii. displayDetails() to display the details of the book
iii. discountedPrice() : pass the discount percent, calculate the discount on price and find the amount to be paid after discount
- task :
Create an object book, initialize the book and display the details along with the discounted price
*/

package assignments_OOPs;

public class Book {
	
	String isbn;
	String title;
	String author;
	double price;
	
	Book(String isbn, String title, String author, double price){
		this.isbn=isbn;
		this.title=title;
		this.author=author;
		this.price=price;
	}
	
	public void displayDetails() {
		System.out.println("Details of the book: ");
		System.out.println();
		System.out.println("ISBN: "+isbn);
		System.out.println("title: "+title);
		System.out.println("Author: "+author);
		System.out.println("price: "+price);
		System.out.println();
	}
	
	public double discountedPrice(double discount) {
		price-=(price * (discount/100));
		return price;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Book book=new Book("MT12345", "Jab We Met", "Mithun Kumar", 500.50);
		book.displayDetails();
		System.out.println("Price of book after Discount: "+book.discountedPrice(25.00));

	}

}
