/*
 * Write a program to create a class Book with the following data members: isbn, title and price. 
 * Inherit the class Book to two derived classes : Magazine and Novel with the following data members:
 * Magazine: type
 * Novel : author
 * Populate the details using constructors.
 * Create a magazine and Novel and display the details.
 */
package assignments_OOPs;

class Books{
	String isbn;
	String title;
	double price;
	
	Books(String isbn,String title,double price){
		this.isbn=isbn;
		this.price=price;
		this.title=title;
	}
	
	public void displaydetails() {
		// TODO Auto-generated method stub
		System.out.println("Book Details: ");
		System.out.println("isbn: "+isbn);
		System.out.println("Title: "+title);
		System.out.println("price: "+price);
	}

	
}

class Magazine extends Books{

	String type;
	Magazine(String isbn, String title, double price, String type) {
		super(isbn, title, price);
		this.type=type;
	}
	@Override
	public void displaydetails() {
		super.displaydetails();
		System.out.println(" Type : " + type);
	}
	
}

class Novel extends Books{

	String author;
	Novel(String isbn, String title, double price, String author) {
		super(isbn, title, price);
		this.author=author;
	}
	@Override
	public void displaydetails() {
		super.displaydetails();
		System.out.println(" Author : " + author);
	}
	
}

public class DisplayBooksAndNovel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Magazine mag = new Magazine("MT12345", "Hindustan Times", 30.00, "Business Magazine");
		Novel novel = new Novel("BT122344", "Winter Wonderland", 50.00, "Alan Stark" );
		
		mag.displaydetails();
		novel.displaydetails();

	}

}
