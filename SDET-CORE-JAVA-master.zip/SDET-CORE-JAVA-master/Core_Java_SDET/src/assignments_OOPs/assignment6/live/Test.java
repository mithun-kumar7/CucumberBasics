package assignments_OOPs.assignment6.live;

import assignments_OOPs.assignment6.music.Playable;
import assignments_OOPs.assignment6.music.string.Veena;
import assignments_OOPs.assignment6.music.wind.Saxophone;

public class Test {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Veena veena=new Veena();
		veena.play();
		Saxophone saxophone=new Saxophone();
		saxophone.play();
		
		Playable p;
		p=veena;
		p.play();
		p=saxophone;
		p.play();
		
	}

}
