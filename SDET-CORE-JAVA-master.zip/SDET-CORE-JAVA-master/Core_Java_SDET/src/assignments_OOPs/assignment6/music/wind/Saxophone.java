package assignments_OOPs.assignment6.music.wind;

import assignments_OOPs.assignment6.music.Playable;

public class Saxophone implements Playable{
	@Override
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("Playing Sexophone");
	}
}
