package assignments_OOPs.assignment6.music;

public interface Playable {
	public void play();
}
