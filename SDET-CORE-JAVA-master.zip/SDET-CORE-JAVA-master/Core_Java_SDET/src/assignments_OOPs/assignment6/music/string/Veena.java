package assignments_OOPs.assignment6.music.string;

import assignments_OOPs.assignment6.music.Playable;

public class Veena implements Playable {
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("Playing Veena");
	}
}
