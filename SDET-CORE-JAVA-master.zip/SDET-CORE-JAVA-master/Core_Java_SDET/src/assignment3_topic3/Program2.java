package assignment3_topic3;

import java.util.Scanner;

class Student {
	String name;
	int s1, s2, s3;

	Student(String name, int s1, int s2, int s3) {
		this.name = name;
		this.s1 = s1;
		this.s2 = s2;
		this.s3 = s3;
	}

	public double average() {
		return (s1 + s2 + s3) / 3;
	}
}

public class Program2 {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String name;
		int s1, s2, s3;
		double avg = 0.0;
		for (int i = 0; i < 2; i++) {
			try {
				System.out.println("Enter Student name and marks for 3 subjects:");
				if (i != 0)
					sc.nextLine();
				name = sc.nextLine();

				if (sc.hasNextInt())
					s1 = sc.nextInt();
				else
					throw new NumberFormatException();
				if (sc.hasNextInt())
					s2 = sc.nextInt();
				else
					throw new NumberFormatException();
				if (sc.hasNextInt())
					s3 = sc.nextInt();
				else
					throw new NumberFormatException();

				Student stud = new Student(name, s1, s2, s3);
				avg = (avg + stud.average()) / (i + 1);
				System.out.println("Average marks for " + name + " : " + stud.average());

			} catch (NumberFormatException ex) {
				System.out.println("Invalid value for marks entered!!");
			}
		}
		System.out.println("Average marks for 2 students : " + avg);
		sc.close();
	}

}
