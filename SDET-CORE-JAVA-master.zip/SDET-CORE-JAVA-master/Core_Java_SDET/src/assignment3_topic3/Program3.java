/*
 * Write a program to accept 5 integers passed as arguments while executing the class. 
 * Find the average of these 5 nos. 
 * Use ArrayIndexOutofBounds exception to handle situation where the
 * user might have entered less than 5 integers.
 */

package assignment3_topic3;

public class Program3 {
	public static void main(String[] args) {

		if(args.length==0) {
			System.out.println("No arguments passed!!");
			return;
		}
		try {
		if(args.length <5)
			throw new ArrayIndexOutOfBoundsException();
		int sum=0;
		for(String s:args) {
			sum+=Integer.parseInt(s);
			System.out.print(s+" ");
		}
		System.out.println("\nAverage : "+(double)sum/5);
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("\n Less than 5 arguments passed!");
		}
	}

}
