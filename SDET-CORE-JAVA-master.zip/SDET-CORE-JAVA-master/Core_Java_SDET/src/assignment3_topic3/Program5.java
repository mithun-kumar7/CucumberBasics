/*
 * Write a program to check the no.of occurrences of a given character within the given string
 * without using any loop. [Hint: String str=�How was your day today�; char c=�a�; no.of
 * occurrences of a is=3]
 */

package assignment3_topic3;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Program5 {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a string : ");
		String str = sc.nextLine();
		System.out.println("Enter character to be searched:");
		char c = sc.next().charAt(0);
		int count=0;
		Matcher match = Pattern.compile(String.valueOf(c)).matcher(str);
		
		while(match.find()) {
			count++;
		}
		
		System.out.println("Occurence of '"+c+"' in '"+str+"' :"+count);
		
	}

}
