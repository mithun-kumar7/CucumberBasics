/*
 * Write a program to check whether the given string is a palindrome or not.
 * [Hint :You have to extract each character from the beginning and end of the String 
 * and compare it with each other. 
 * String x=�Malayalam�; char c= x.charAt(i) where i is the index]
 */

package assignment3_topic3;

import java.util.Scanner;

public class Program4 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a string: ");
		String str = sc.next();
		boolean flag=true;
		int len = str.length();
		for(int i=0;i<len;i++) {
			
			char c = str.charAt(i);
			char c1 = str.charAt(len-(i+1));
			
			if(Character.toLowerCase(c)!=Character.toLowerCase(c1)) {
				System.out.println("String is not Pallindrome!");
				flag=false;
				break;
			}
		}

		if(flag)
			System.out.println("It is a Pallindrome!!! ");
	}

}
