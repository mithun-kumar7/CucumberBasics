# SDET-CORE-JAVA
Core-Java assignments
